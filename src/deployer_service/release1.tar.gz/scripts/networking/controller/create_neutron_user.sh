#!/bin/bash
openstack user create --domain default --password-prompt neutron
