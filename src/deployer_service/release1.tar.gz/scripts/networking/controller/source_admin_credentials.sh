#!/bin/bash
. admin-openrc
