#!/bin/bash
$OPENSTACK_DEPLOYER_PATH/os/$OPENSTACK_OS_VERSION/apt/install_package.sh glance

