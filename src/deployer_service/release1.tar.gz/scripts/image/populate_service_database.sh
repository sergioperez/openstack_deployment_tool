#!/bin/bash

su -s /bin/sh -c "glance-manage db_sync" glance
