#!/bin/bash

apt-get update
