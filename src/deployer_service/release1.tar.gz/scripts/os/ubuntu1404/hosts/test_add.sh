./add_host.sh 127.0.0.1 micasa ./hosts_original

