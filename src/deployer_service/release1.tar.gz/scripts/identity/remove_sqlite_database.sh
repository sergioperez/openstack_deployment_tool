#!/bin/bash

rm -f $KEYSTONE_SQLITE_PATH
