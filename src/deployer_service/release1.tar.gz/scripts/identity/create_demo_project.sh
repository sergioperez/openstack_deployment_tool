#!/bin/bash
openstack project create --domain default \
  --description "Demo Project" demo
