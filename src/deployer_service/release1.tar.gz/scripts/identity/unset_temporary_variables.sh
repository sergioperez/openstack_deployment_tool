#!/bin/bash
unset OS_TOKEN OS_URL
