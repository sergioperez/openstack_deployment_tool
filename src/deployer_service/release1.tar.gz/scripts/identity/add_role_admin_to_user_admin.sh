#!/bin/bash
openstack role add --project admin --user admin admin
