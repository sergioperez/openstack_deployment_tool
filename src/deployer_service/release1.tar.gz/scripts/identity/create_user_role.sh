#!/bin/bash
openstack role create user
