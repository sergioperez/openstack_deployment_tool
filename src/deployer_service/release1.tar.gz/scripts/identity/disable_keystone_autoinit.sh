#!/bin/bash
KEYSTONE_OVERRIDE_PATH="/etc/init/keystone.override"
echo "manual" > $KEYSTONE_OVERRIDE_PATH
