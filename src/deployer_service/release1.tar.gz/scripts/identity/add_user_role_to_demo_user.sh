#!/bin/bash

openstack role add --project demo --user demo user
