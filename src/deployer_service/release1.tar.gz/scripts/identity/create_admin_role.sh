#!/bin/bash
openstack role create admin
