#!/bin/bash
openstack domain create --description "Default Domain" default
