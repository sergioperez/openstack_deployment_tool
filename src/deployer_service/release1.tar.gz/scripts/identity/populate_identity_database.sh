#!/bin/bash
su -s /bin/sh -c "keystone-manage db_sync" keystone
