#!/bin/bash

#TODO: Check if PATH INTERFACES is not empty

IP=$1
MASK=$2
GATEWAY=$3

echo IP $1 MASK $2 GATEWAY $3
