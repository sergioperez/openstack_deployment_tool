#!/bin/bash

service chrony restart
