#!/bin/bash
../os/apt/install_package.sh rabbitmq-server
