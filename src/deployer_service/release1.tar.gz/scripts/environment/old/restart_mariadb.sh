#!/bin/bash
service mysql restart
