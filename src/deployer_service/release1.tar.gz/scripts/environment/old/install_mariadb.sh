#!/bin/bash
../os/apt/install_package.sh mariadb-server
../os/apt/install_package.sh python-pymysql
