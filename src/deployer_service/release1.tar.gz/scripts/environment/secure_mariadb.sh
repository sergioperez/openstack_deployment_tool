#!/bin/bash
mysql_secure_installation

