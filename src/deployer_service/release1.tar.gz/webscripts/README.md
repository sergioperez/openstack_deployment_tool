When installing something, you always have to call check before
