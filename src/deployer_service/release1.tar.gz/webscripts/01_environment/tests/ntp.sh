#!bin/bash

chronyc sources
