#!/bin/bash

#TODO: Parse arguments

$OPENSTACK_DEPLOYER_PATH/os/$OPENSTACK_OS_VERSION/hosts/add_host.sh $1 $2
