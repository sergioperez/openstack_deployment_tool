#!/bin/bash
rabbitmqctl set_permissions openstack ".*" ".*" ".*"
