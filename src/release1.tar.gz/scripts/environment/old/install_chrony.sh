#!/bin/bash
../os/install_package.sh chrony
