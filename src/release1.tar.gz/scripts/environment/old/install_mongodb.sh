#!/bin/bash
../os/apt/package_install.sh mongodb-server
../os/apt/package_install.sh mongodb-clients
../os/apt/package_install.sh python-pymongo
