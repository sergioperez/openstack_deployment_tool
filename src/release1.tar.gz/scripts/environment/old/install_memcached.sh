#!/bin/bash
../os/apt/install_package.sh memcached
../os/apt/install_package.sh python-memcache
