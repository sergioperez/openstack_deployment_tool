/remove_host.sh micasa ./hosts_original

