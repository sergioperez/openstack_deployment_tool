echo "Testing chronyc configuration"
chronyc sources >> output
