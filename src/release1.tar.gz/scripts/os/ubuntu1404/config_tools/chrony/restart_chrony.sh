echo "Restarting chrony"
service chrony restart

