#!/bin/bash
$OPENSTACK_DEPLOYER_PATH/os/$OPENSTACK_OS_VERSION/packages/install_package.sh neutron-linuxbridge-agent


