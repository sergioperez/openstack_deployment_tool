#!/bin/bash
openstack role add --project service --user neutron admin
