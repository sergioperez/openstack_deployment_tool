#!/bin/bash

openstack project create --domain default \
  --description "Admin Project" admin
