#!/bin/bash

openstack project create --domain default \
  --description "Service Project" service
