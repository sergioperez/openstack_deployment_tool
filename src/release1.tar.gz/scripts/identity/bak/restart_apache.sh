#!/bin/bash

/os/ubuntu/services/restart_service.sh apache2
