#!/bin/bash

/os/ubuntu/apt/install_package.sh keystone
/os/ubuntu/apt/install_package.sh apache2
/os/ubuntu/apt/install_package.sh libapache2-mod-wsgi

