KEYSTONE_OVERRIDE_PATH="/etc/init/keystone.override"
KEYSTONE_SQLITE_PATH="rm -f /var/lib/keystone/keystone.db"
IDENTITY_API_VERSION=3
