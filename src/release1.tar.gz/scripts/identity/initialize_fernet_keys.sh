#!/bin/bash
keystone-manage fernet_setup --keystone-user keystone --keystone-group keystone
