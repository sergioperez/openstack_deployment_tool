#!/bin/bash

ping -c 2 controller
ping -c 2 compute
