#!/bin/bash

FILE=$1

if [ -f $FILE ]
then
	echo ola
else
	echo adio
fi 
